export const environment = {
  production: true,
  API_URL: 'https://vivero-quilino.onrender.com/api---->solo de ejemplo',
  API_URL_PRODUCTOS: 'https://vivero-quilino.onrender.com/api',
};
