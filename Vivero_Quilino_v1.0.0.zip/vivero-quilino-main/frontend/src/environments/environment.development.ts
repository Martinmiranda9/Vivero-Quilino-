export const environment = {
    production: false,
    API_URL: 'https://vivero-quilino.onrender.com/api',
    API_URL_PRODUCTOS: 'https://vivero-quilino.onrender.com/api',
};
