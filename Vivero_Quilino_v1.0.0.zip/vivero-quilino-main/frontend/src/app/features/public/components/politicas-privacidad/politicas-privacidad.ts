import { Component } from '@angular/core';

@Component({
  selector: 'app-politicas-privacidad',
  imports: [],
  templateUrl: './politicas-privacidad.html'
})
export class PoliticasPrivacidad {

}
