import { Component } from '@angular/core';

@Component({
  selector: 'app-terminos-condiciones',
  imports: [],
  templateUrl: './terminos-condiciones.html'
})
export class TerminosCondiciones {

}
