export interface Temporada{
    id: number;
    nombre: string;
}