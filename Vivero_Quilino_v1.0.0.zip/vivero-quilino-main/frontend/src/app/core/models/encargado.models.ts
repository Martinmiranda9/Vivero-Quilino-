export interface Encargado{
    id?: number;
    nombre?: string;
    foto?: string;
    descripcion?: string;
}
