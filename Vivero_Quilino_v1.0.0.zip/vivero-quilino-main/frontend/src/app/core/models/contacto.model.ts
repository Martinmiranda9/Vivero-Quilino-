export interface Contacto {
  id: number;
  horario_atencion: string;
  email: string;
  telefono: string;
  whatsapp: string;
}
