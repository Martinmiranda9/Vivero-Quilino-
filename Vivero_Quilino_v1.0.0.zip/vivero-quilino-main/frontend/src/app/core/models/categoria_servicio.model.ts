export interface Categoria_servicio {
    id: number;
    nombre: string;
    tipo: string;
    id_padre: number;
    imagen_url: string;
    imagen2_url: string;
}